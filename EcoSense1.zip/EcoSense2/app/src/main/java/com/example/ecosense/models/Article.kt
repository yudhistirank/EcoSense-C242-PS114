package com.example.ecosense.models

data class Article(
    val id: String,
    val title: String,
    val category: String,
    val description: String
)
