package com.example.ecosense.models

data class PredictionHistory(
    val itemName: String,
    val category: String,
    val date: String
)
